package com;

import java.time.Duration;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.Keys;
public class App {
    public static void main(String[] args) {
        // Setting up Chrome WebDriver
        WebDriverManager.chromedriver().setup();
        WebDriver chromeDriver = new ChromeDriver();
        navigateAndTest(chromeDriver);
        

        // Setting up Edge WebDriver
       
        WebDriverManager.edgedriver().setup();
        WebDriver edgeDriver = new EdgeDriver();
        navigateAndTest(edgeDriver);

   
      //   Quit all drivers
         chromeDriver.quit();
         System.out.println("Chrome Closed ");
         edgeDriver.quit();
         System.out.println("Edge Closed");
       
    }

    public static void navigateAndTest(WebDriver driver) {
        driver.manage().window().maximize();
        driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
        driver.get("https://www.flipkart.com/");
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);


        // Search for "iPhone 13" in the search bar
        driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div/div/div/div/div[1]/div/div[1]/div/div[2]/div[1]/div/div[1]/div/div/div/div/div[1]/a[2]")).click();
        driver.findElement(By.className("_3704LK")).sendKeys("iPhone 13");
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        driver.findElement(By.className("L0Z3Pu")).click();
        


      
     // Scroll to the bottom of the page
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(By.tagName("body"))).sendKeys(Keys.END).perform();
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        System.out.println("Scroll is done");



      
        // Check if the search results are visible
        WebElement searchResults = driver.findElement(By.className("L0Z3Pu"));
        if (searchResults.isDisplayed()) {
            System.out.println("Search results are visible.");
        } else {
            System.out.println("Search results are not visible.");
        }
        
    }
}
