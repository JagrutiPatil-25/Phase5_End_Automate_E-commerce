package com;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;


import io.github.bonigarcia.wdm.WebDriverManager;
public class FlipkartTest {
	
	private WebDriver driver;
    SoftAssert soft = new SoftAssert();
    
    @Test(priority = 1)
    public void testSearchOnEdge() {
        // Setting up Edge WebDriver
        WebDriverManager.edgedriver().setup();
        WebDriver edgeDriver = new EdgeDriver();
        navigateAndTest(edgeDriver);
        edgeDriver.quit();
    }
    
    @Test(priority = 2)
    public void testSearchOnChrome() {
        // Setting up Edge WebDriver
    	   WebDriverManager.chromedriver().setup();
           WebDriver chromeDriver = new ChromeDriver();
           navigateAndTest(chromeDriver);
           chromeDriver.quit();
    }

    public void navigateAndTest(WebDriver driver) {
    	 driver.manage().window().maximize();
         driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
         driver.get("https://www.flipkart.com/");
         driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);


         // Search for "iPhone 13" in the search bar
         driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div/div/div/div/div[1]/div/div[1]/div/div[2]/div[1]/div/div[1]/div/div/div/div/div[1]/a[2]")).click();
         driver.findElement(By.className("_3704LK")).sendKeys("iPhone 13");
         driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
         driver.findElement(By.className("L0Z3Pu")).click();
         


       
      // Scroll to the bottom of the page
         Actions actions = new Actions(driver);
         actions.moveToElement(driver.findElement(By.tagName("body"))).sendKeys(Keys.END).perform();
         driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
         System.out.println("Scroll is done");



       
         // Check if the search results are visible
         WebElement searchResults = driver.findElement(By.className("L0Z3Pu"));
         if (searchResults.isDisplayed()) {
             System.out.println("Search results are visible.");
         } else {
             System.out.println("Search results are not visible.");
         }
         
     }
}
